package com.arvatosystems.us.training;

import com.arvatosystems.us.training.dep.Order;

/**
 * Requirements: 
 * Please implement a simple {@link TaxService} that executes different tax rules based on the order's country.
 * The solution should make it easy to add more country dependent tax rules in future. The actual logic to 
 * calculate taxes is *not* part of the exercise. ;-)
 */
public interface TaxService 
{
	public void calculateTax(Order order);
	
	public void addCountry(String name);
	
	public void countryId(int id);
	
}
