package com.arvatosystems.us.training;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * You may use org.apache.commons.lang.StringUtils and org.apache.commons.collections.CollectionUtils!
 */
public class Lists {

	/**
	 * Returns a new filtered and sorted list.
	 * All blank strings are filtered out and and the returned list entries are sorted in ascending order, 
	 * according to the natural ordering of its elements
	 * @param The list
	 * @return A new filtered list
	 * @throws IllegalArgumentException Raised if the given list is empty.
	 */
	public List<String> filterList(final List<String> list) throws IllegalArgumentException
	{
		ArrayList al =new ArrayList();
		Object e =null;
		al.add(e);

		
	
	}
	
}
