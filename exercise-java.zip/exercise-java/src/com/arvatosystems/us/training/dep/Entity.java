package com.arvatosystems.us.training.dep;

public interface Entity {

}
