package com.arvatosystems.us.training.dep;

public interface Order
{
	String getCountryISOCode();
}
